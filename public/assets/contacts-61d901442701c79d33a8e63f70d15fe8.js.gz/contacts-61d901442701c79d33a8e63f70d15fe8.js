$(document).ready(function(){
	$("#menu ul.main-menu li.main-menu.contact a").addClass("active");
});
