$(document).ready(function(){
$("#menu ul.main-menu li.main-menu.news a").addClass("active");
});
