$(document).ready(function(){
	$("#menu ul.main-menu li.main-menu.home a").addClass("active");
});
