$(document).ready(function(){
$("#menu ul.main-menu li.main-menu.product a").addClass("active");
});
